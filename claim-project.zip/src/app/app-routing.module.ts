import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DealerTaskListComponent } from './dealer/dealer-task-list/dealer-task-list.component';
import { DealerTaskDetailsComponent } from './dealer/dealer-task-details/dealer-task-details.component';
import { DealerCreateTaskComponent } from './dealer/dealer-create-task/dealer-create-task.component';
import { DealerTaskStarterComponent } from './dealer/dealer-task-starter/dealer-task-starter.component';
import { InternalTaskListComponent } from './internal/internal-task-list/internal-task-list.component';
import { InternalTaskDetailsComponent } from './internal/internal-task-details/internal-task-details.component';
import { InternalCreateTaskComponent } from './internal/internal-create-task/internal-create-task.component';



const appRoutes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },

  { path: 'home', component: DealerTaskStarterComponent },

  { path: 'd-task-list', component: DealerTaskListComponent },
  { path: 'd-task-details', component: DealerTaskDetailsComponent },
  { path: 'd-add-task', component: DealerCreateTaskComponent },

  { path: 'i-task-list', component: InternalTaskListComponent },
  { path: 'i-task-details', component: InternalTaskDetailsComponent },
  { path: 'i-add-task', component: InternalCreateTaskComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
