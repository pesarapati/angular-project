import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { FormsModule}   from '@angular/forms';

import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { DealerTaskListComponent } from './dealer/dealer-task-list/dealer-task-list.component';
import { DealerCreateTaskComponent } from './dealer/dealer-create-task/dealer-create-task.component';
import { DealerTaskDetailsComponent } from './dealer/dealer-task-details/dealer-task-details.component';
import { DealerTaskStarterComponent } from './dealer/dealer-task-starter/dealer-task-starter.component';
import { InternalCreateTaskComponent } from './internal/internal-create-task/internal-create-task.component';
import { InternalTaskDetailsComponent } from './internal/internal-task-details/internal-task-details.component';
import { InternalTaskListComponent } from './internal/internal-task-list/internal-task-list.component';

import { ClaimService } from './claim.service';

@NgModule({
  declarations: [
    AppComponent,
    DealerTaskListComponent,
    DealerCreateTaskComponent,
    DealerTaskDetailsComponent,
    DealerTaskStarterComponent,
    InternalCreateTaskComponent,
    InternalTaskDetailsComponent,
    InternalTaskListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpModule,
    FormsModule,

    TableModule,
    InputTextModule,
    DialogModule,
    ButtonModule
  ],
  providers: [ClaimService],
  bootstrap: [AppComponent]
})
export class AppModule { }
