export class DealerInfo {
    constructor(public chassis : string,
        public mileage : string){
    }
}
