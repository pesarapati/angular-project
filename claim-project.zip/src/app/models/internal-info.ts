export class InternalInfo {
    constructor(public chassis : string,
        public mileage : string,
        public extraInput : string){
    }
}
