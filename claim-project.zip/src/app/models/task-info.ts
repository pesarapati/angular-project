export class TaskInfo {

    taskId : number
    userMasterId : number
    createdFname : string   
}
