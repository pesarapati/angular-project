import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-internal-task-details',
  templateUrl: './internal-task-details.component.html',
  styleUrls: ['./internal-task-details.component.css']
})
export class InternalTaskDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
