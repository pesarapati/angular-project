import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternalTaskDetailsComponent } from './internal-task-details.component';

describe('InternalTaskDetailsComponent', () => {
  let component: InternalTaskDetailsComponent;
  let fixture: ComponentFixture<InternalTaskDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternalTaskDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternalTaskDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
