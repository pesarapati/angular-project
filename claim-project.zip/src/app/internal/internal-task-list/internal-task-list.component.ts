import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClaimService } from '../../claim.service';
import { TaskInfo } from '../../models/task-info';

@Component({
  selector: 'app-internal-task-list',
  templateUrl: './internal-task-list.component.html',
  styleUrls: ['./internal-task-list.component.css']
})
export class InternalTaskListComponent implements OnInit {

  constructor(private router: Router,
    private claimService : ClaimService) {
  }
  
  
    taskList : TaskInfo[];
  
    ngOnInit() {
      this.getDealerTasks();
    }
    
    getDealerTasks():void{
      this.claimService.getInternalTasks().subscribe(
        data =>{
          this.taskList = data;
          console.log('Before  data'+JSON.stringify(data));
        },err =>{
          console.log('Error while fetching the dealer tasks data');
        }
      );
    } 
  
  
    get data(){
      return JSON.stringify(this.taskList);
    } 

}
