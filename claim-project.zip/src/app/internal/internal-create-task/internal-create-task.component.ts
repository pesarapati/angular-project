import { Component, OnInit } from '@angular/core';
import { InternalInfo } from '../../models/internal-info';
import { ClaimService } from '../../claim.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-internal-create-task',
  templateUrl: './internal-create-task.component.html',
  styleUrls: ['./internal-create-task.component.css']
})
export class InternalCreateTaskComponent implements OnInit {

  private internalInput : InternalInfo;

  constructor(private claimService:ClaimService,private _rotuer:Router) { }

  ngOnInit() {

    this.internalInput = new InternalInfo(null,null,null);
  }

  submitInternalForm(){
       this.claimService.submitInternalDeatils(this.internalInput).subscribe(
         (data)=>{
         console.log(data);
         this.internalInput = data;
         this._rotuer.navigate(['i-task-details']);
       },(error)=>{
         console.log(error);
       });

       this._rotuer.navigate(['i-task-details']); // Deleet later once service is correct
  }


  get data(){
    return JSON.stringify(this.internalInput);
  } 

}
