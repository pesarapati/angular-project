import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dealer-task-details',
  templateUrl: './dealer-task-details.component.html',
  styleUrls: ['./dealer-task-details.component.css']
})
export class DealerTaskDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  
  get data(){
    return JSON.stringify('');
  } 

}
