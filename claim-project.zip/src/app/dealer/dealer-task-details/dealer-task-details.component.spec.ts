import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealerTaskDetailsComponent } from './dealer-task-details.component';

describe('DealerTaskDetailsComponent', () => {
  let component: DealerTaskDetailsComponent;
  let fixture: ComponentFixture<DealerTaskDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealerTaskDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealerTaskDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
