import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TaskInfo } from '../../models/task-info';
import { ClaimService } from '../../claim.service';

@Component({
  selector: 'app-dealer-task-list',
  templateUrl: './dealer-task-list.component.html',
  styleUrls: ['./dealer-task-list.component.css']
})
export class DealerTaskListComponent implements OnInit {

  constructor(private router: Router,
              private claimService : ClaimService) {
  }

  taskHeaders: any[];
  taskList : TaskInfo[];

  ngOnInit() {
    this.getDealerTasks();

    this.taskHeaders = [
      { field: 'taskId', header: 'Task Id' },
      { field: 'createdFname', header: 'First Name'}
    ];

  }
  
  getDealerTasks():void{
    this.claimService.getDealerTasks().subscribe(
      data =>{
        this.taskList = data;
        console.log('Before  data'+JSON.stringify(data));
      },err =>{
        console.log('Error while fetching the dealer tasks data');
      }
    );
  } 


  get data(){
    return JSON.stringify(this.taskList);
  } 

}
