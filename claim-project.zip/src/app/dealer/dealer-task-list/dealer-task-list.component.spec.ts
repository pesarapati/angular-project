import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealerTaskListComponent } from './dealer-task-list.component';

describe('DealerTaskListComponent', () => {
  let component: DealerTaskListComponent;
  let fixture: ComponentFixture<DealerTaskListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealerTaskListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealerTaskListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
