import { Component, OnInit } from '@angular/core';
import { ClaimService } from '../../claim.service';
import { Router } from '@angular/router';
import { DealerInfo } from '../../models/dealer-info';

@Component({
  selector: 'app-dealer-create-task',
  templateUrl: './dealer-create-task.component.html',
  styleUrls: ['./dealer-create-task.component.css']
})
export class DealerCreateTaskComponent implements OnInit {

  private dealerInput :DealerInfo;

  constructor(private claimService:ClaimService,private _rotuer:Router) { }

  ngOnInit() {
    this.dealerInput = new DealerInfo(null,null);
  }

  submitDealerForm(){
       this.claimService.submitDealerDeatils(this.dealerInput).subscribe(
         (data)=>{
         console.log(data);
         this.dealerInput = data;
         this._rotuer.navigate(['d-task-details']);
       },(error)=>{
         console.log(error);
       });

       this._rotuer.navigate(['d-task-details']); // Deleet later once service is correct
  }


  get data(){
    return JSON.stringify(this.dealerInput);
  } 


}
