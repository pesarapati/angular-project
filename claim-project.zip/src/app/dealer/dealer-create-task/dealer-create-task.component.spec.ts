import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealerCreateTaskComponent } from './dealer-create-task.component';

describe('DealerCreateTaskComponent', () => {
  let component: DealerCreateTaskComponent;
  let fixture: ComponentFixture<DealerCreateTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealerCreateTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealerCreateTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
