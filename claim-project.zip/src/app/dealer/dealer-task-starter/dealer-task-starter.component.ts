import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClaimService } from '../../claim.service';

@Component({
  selector: 'app-dealer-task-starter',
  templateUrl: './dealer-task-starter.component.html',
  styleUrls: ['./dealer-task-starter.component.css']
})
export class DealerTaskStarterComponent implements OnInit {

  constructor(private router: Router,  private route: ActivatedRoute,
         private claimService : ClaimService) { }

  isDealer = false;
  ngOnInit() {
    this.getLoginUserType();

    this.isDealer = true;

    if(this.isDealer){
      this.router.navigate(['d-task-list']);
    }else{
      this.router.navigate(['i-task-list']);
    }
  }


  getLoginUserType():void{
    this.claimService.getLoginUserType().subscribe(
      data =>{
        this.isDealer = data;
        console.log('Before  data'+JSON.stringify(data));
      },err =>{
        console.log('Error while fetching the getLoginUserType() data');
      }
    );
  }

}
