import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { FormsModule}   from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { DialogModule, } from 'primeng/dialog';
import {FileUploadModule} from 'primeng/fileupload';
import {CalendarModule} from 'primeng/calendar';
import {TooltipModule} from 'primeng/tooltip';


import {GrowlModule} from 'primeng/growl';
import {AccordionModule} from 'primeng/accordion';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { DealerTaskListComponent } from './dealer/dealer-task-list/dealer-task-list.component';
import { DealerCreateTaskComponent } from './dealer/dealer-create-task/dealer-create-task.component';
import { DealerTaskDetailsComponent } from './dealer/dealer-task-details/dealer-task-details.component';
import { DealerTaskStarterComponent } from './dealer/dealer-task-starter/dealer-task-starter.component';
import { InternalCreateTaskComponent } from './internal/internal-create-task/internal-create-task.component';
import { InternalTaskDetailsComponent } from './internal/internal-task-details/internal-task-details.component';
import { InternalTaskListComponent } from './internal/internal-task-list/internal-task-list.component';

import { ClaimService } from './claim.service';
import { SimulateTaskDtailsComponent } from './internal/simulate-task-dtails/simulate-task-dtails.component';

import {InputTextareaModule} from 'primeng/inputtextarea';

@NgModule({
  declarations: [
    AppComponent,
    DealerTaskListComponent,
    DealerCreateTaskComponent,
    DealerTaskDetailsComponent,
    DealerTaskStarterComponent,
    InternalCreateTaskComponent,
    InternalTaskDetailsComponent,
    InternalTaskListComponent,
    SimulateTaskDtailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    BrowserAnimationsModule,

    TableModule,
    InputTextModule,
    DialogModule,
    ButtonModule,
    FileUploadModule,
    CalendarModule,
    GrowlModule,
    AccordionModule,
    InputTextareaModule,
    TooltipModule

  ],
  providers: [ClaimService],
  bootstrap: [AppComponent]
})
export class AppModule { }
