import { Component, OnInit } from '@angular/core';
import { TaskDetails } from '../../models/task-details';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ClaimService } from '../../claim.service';
import { DefectDetailsHeaders, VinClaimHeaders } from '../../models/claim-constants';

@Component({
  selector: 'app-simulate-task-dtails',
  templateUrl: './simulate-task-dtails.component.html',
  styleUrls: ['./simulate-task-dtails.component.css']
})
export class SimulateTaskDtailsComponent implements OnInit {

  taskDetails: TaskDetails;
  defectDetailsHeaders: any[];
  vinClaimHeaders: any[];


  constructor(private route: ActivatedRoute, private location: Location, private claimService: ClaimService) {
    
  }

  ngOnInit() {

    this.defectDetailsHeaders = DefectDetailsHeaders;
    this.vinClaimHeaders = VinClaimHeaders;

    if (localStorage.length > 0) {
      this.taskDetails = JSON.parse(atob(localStorage.getItem('simulate-taskdetails-response')));
      console.log('simulate-taskdetails-response from localStorage : ', JSON.stringify(this.taskDetails));
    }
  }
  

 

  goback(): void {
    this.location.back();
  }

  get data() {
    return JSON.stringify(this.taskDetails);
  }

}
