import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimulateTaskDtailsComponent } from './simulate-task-dtails.component';

describe('SimulateTaskDtailsComponent', () => {
  let component: SimulateTaskDtailsComponent;
  let fixture: ComponentFixture<SimulateTaskDtailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimulateTaskDtailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimulateTaskDtailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
