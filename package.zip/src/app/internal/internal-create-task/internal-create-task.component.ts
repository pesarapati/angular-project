import { Component, OnInit } from '@angular/core';
import { InternalInfo } from '../../models/internal-info';
import { ClaimService } from '../../claim.service';
import { Router, NavigationExtras } from '@angular/router';


@Component({
  selector: 'app-internal-create-task',
  templateUrl: './internal-create-task.component.html',
  styleUrls: ['./internal-create-task.component.css']
})
export class InternalCreateTaskComponent implements OnInit {

   internalInput : InternalInfo;

  constructor(private claimService:ClaimService,private _rotuer:Router) { }

  ngOnInit() {
    this.internalInput = new InternalInfo(null,null,null);
  }

  submitInternalForm(){ //submitDealerDeatils
       this.claimService.submitDealerDeatils(this.internalInput).subscribe(
         (data)=>{
          console.log('simulate-taskdetails-response : ',data);
          localStorage.setItem('simulate-taskdetails-response', btoa(JSON.stringify(data))); // Store in localstore
         this._rotuer.navigate(['is-task-details']);
       },(error)=>{
         console.log(error);
       });
  }


  get data(){
    return JSON.stringify(this.internalInput);
  } 
  


}
