import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternalCreateTaskComponent } from './internal-create-task.component';

describe('InternalCreateTaskComponent', () => {
  let component: InternalCreateTaskComponent;
  let fixture: ComponentFixture<InternalCreateTaskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternalCreateTaskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternalCreateTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
