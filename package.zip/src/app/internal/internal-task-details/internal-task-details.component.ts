import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { ClaimService } from '../../claim.service';
import { TaskDetails } from '../../models/task-details';
import { InternalInfo } from '../../models/internal-info';
import { InlineEdit } from '../../models/inline-edit';
import { DefectDetailsHeaders, VinClaimHeaders } from '../../models/claim-constants';

@Component({
  selector: 'app-internal-task-details',
  templateUrl: './internal-task-details.component.html',
  styleUrls: ['./internal-task-details.component.css']
})
export class InternalTaskDetailsComponent implements OnInit {

  taskDetails: TaskDetails;
  defectDetailsHeaders: any[];
  vinClaimHeaders: any[];
  inlineEdit : InlineEdit = new InlineEdit();

  hide : boolean = true;

  commentsList : any[] =  [ { val: 'First comment been added by the dealer'  },  { val: 'second comment been added by the dealer ' },  { val: 'second comment been added by the dealer ' } ];



  constructor(private route: ActivatedRoute, private location: Location, private claimService: ClaimService) {

  }

  ngOnInit() {

    this.defectDetailsHeaders = DefectDetailsHeaders;
    this.vinClaimHeaders = VinClaimHeaders;

    if (localStorage.length > 0) {
      this.taskDetails = JSON.parse(atob(localStorage.getItem('internal-taskdetails-response')));
      console.log('taskdeatils from localStorage : ', JSON.stringify(this.taskDetails));
    }
  }


  showComments: boolean = false;

  showCommentsDialog() {
      this.showComments = true;
  }


  submitTaskDetailsForm() {
    console.log('submitTaskDetailsForm fired : ', JSON.stringify(this.taskDetails));
  }

  goback(): void {
    this.location.back();
  }

  get data() {
    return JSON.stringify(this.taskDetails);
  }
}
