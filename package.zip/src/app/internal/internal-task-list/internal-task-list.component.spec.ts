import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternalTaskListComponent } from './internal-task-list.component';

describe('InternalTaskListComponent', () => {
  let component: InternalTaskListComponent;
  let fixture: ComponentFixture<InternalTaskListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternalTaskListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternalTaskListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
