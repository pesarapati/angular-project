import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { ClaimService } from '../../claim.service';
import { TaskInfo } from '../../models/task-info';
import { InternalTaskHeaders } from '../../models/claim-constants';

@Component({
  selector: 'app-internal-task-list',
  templateUrl: './internal-task-list.component.html',
  styleUrls: ['./internal-task-list.component.css']
})
export class InternalTaskListComponent implements OnInit {

  constructor(private router: Router,
    private claimService: ClaimService) {
  }

  taskHeaders: any[];
  taskList: TaskInfo[];
  selectedViewTask: TaskInfo;
  taskFilterValue: string = "";
  vinFilterValue: string = "";
  agCodeFilterValue: string = "";
  createdByFilterValue: string = "";
  statusFilterValue: string = "";
  subStatusFilterValue: string = "";
  ownedByFilterValue: string = "";
  actionsFilterValue: string = "";


  ngOnInit() {
    this.getInternalTasks();
    this.taskHeaders = InternalTaskHeaders;
  }

  getInternalTasks(): void {
    this.claimService.getInternalTasks().subscribe(
      data => {
        this.taskList = data;
        console.log('Before  data' + JSON.stringify(data));
      }, err => {
        console.log('Error while fetching the internal tasks data');
      }
    );
  }


  viewSelectedInternalTask(taskInfo: TaskInfo) { //viewDealerTask
    this.claimService.viewDealerTask(taskInfo.taskId).subscribe(
      data => {
        console.log('viewSelectedInternalTask response : ', JSON.stringify(data));
        localStorage.setItem('internal-taskdetails-response', btoa(JSON.stringify(data))); // Store in localstore
        this.router.navigate(['i-task-details']);
      }, err => {
        console.log('Error while fetching viewSelectedInternalTask()');
      }
    );
  }

  get data() {
    return JSON.stringify(this.taskList);
  }

  vinKeyUp(event) {
    this.vinFilterValue = event.target.value;
  }

  taskKeyUp(event) {
    this.taskFilterValue = event.target.value;
  }

  agCodeKeyUp(event) {
    this.agCodeFilterValue = event.target.value;
  }

  createdByKeyUp(event) {
    this.createdByFilterValue = event.target.value;
  }

  statusKeyUp(event) {
    this.statusFilterValue = event.target.value;
  }

  subStatusKeyUp(event) {
    this.subStatusFilterValue = event.target.value;
  }

  ownedByKeyUp(event) {
    this.ownedByFilterValue = event.target.value;
  }

  actionsKeyUp(event) {
    this.actionsFilterValue = event.target.value;
  }

}
