import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { DealerInfo } from './models/dealer-info';
import { InternalInfo } from './models/internal-info';

@Injectable({
  providedIn: 'root'
})
export class ClaimService {

  public storage: any;

  private serviceBaseURL='http://localhost:8080/vcr/';
  
  constructor(private http: HttpClient) { }

  getCenterDetails(): Observable<any> {
    return this.http.get(this.serviceBaseURL +'centerDetails');
  }


  getInternalTasks(): Observable<any> {
    return this.http.get(this.serviceBaseURL +'internalTaskList');
  }

  getDealerTasks(): Observable<any> {
    return this.http.get(this.serviceBaseURL +'dealerTaskList');
  }

  submitDealerDeatils(dealerInput : DealerInfo): Observable<any> {
    console.log('inside service dealer input data :'+JSON.stringify(dealerInput));
    return this.http.post(this.serviceBaseURL +'dealerSubmit',dealerInput);
  }

  submitInternalDeatils(internalInput : InternalInfo): Observable<any> {
    console.log('inside service Internal input data :'+JSON.stringify(internalInput));
    return this.http.post(this.serviceBaseURL +'internalSubmit',internalInput);
  }

  viewDealerTask(taskId : string): Observable<any> {
    console.log('View Dealer selected task  :'+taskId);
    return this.http.post(this.serviceBaseURL +'viewDealerTask',taskId);
  }

  viewInternalTask(taskId : string): Observable<any> {
    console.log('View Internal selected task  :'+taskId);
    return this.http.post(this.serviceBaseURL +'viewInternalTask',taskId);
  }




    
}
