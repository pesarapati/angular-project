export class CenterDetails {

    public centerId: string;
    public centerDesc: string;
    public dealer: boolean;
}
