export class DefectDetails {

    public defectCode : string;
	public defectDesc : string;
	public saleStartDate : string;
	public availableDate : string;
	public repairDate : string;
	public eligibilityStartDate : string;
	public claimStartDate : string;
	public claimEndDate : string;
}

