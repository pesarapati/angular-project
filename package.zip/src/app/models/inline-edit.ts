export class InlineEdit {

    constructor( public InvEntryDatenew : boolean = false, public InvExitDatenew : boolean = false,
        public InvEntryDateused : boolean = false, public InvExitDateused : boolean = false,
         public whlSalePrice : boolean = false, public vehicleMMRvalue : boolean = false,
          public revisedMMRvalue : boolean = false, public MMRMarkup : boolean = false,
          public clmAmountUsed : boolean = false, public claimAmountnew : boolean = false,
           public totalClaimAmount : boolean = false,
           public eligiblePeriodnew : boolean = false,
           public eligiblePeriodused : boolean = false){

    }

}
