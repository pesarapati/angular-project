import { DefectDetails } from "./defect-details";

export class UsedVehicle {
	
    public inventoryEntryDate : string; 
    public inventoryExitDate : string;
    public mileage : string;
    public vehicleMMRValue : string;
    public mmrMarkup : string;
	public revisedMMRValue : string;
	public defectDetails : DefectDetails[];
	public eligibilityPeriod : String[];
	public noOfDays : string;
	public noOfMonths : string;
    public claimAmount : string;
}