export class VinClaim {
    public claimAmount : string;
    public claimNumber : string;
    public claimPeriod : string;
    public detailsEdited : string;
}
