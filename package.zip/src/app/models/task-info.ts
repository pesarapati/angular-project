export class TaskInfo {

        public taskId : string;
        public vin : string;
        public milleage : number;
        public status : string;
        public statusDate : string;
        public reimAmount : string;
        public claimEndDate : string;
       

        // Internal
        public agCodeDesc : string;
        public createdBy : string;
        public subStatus : string;
        public subStatusDate : string;
        public manualDate : string;
        public ownedBy : string;

     
}

