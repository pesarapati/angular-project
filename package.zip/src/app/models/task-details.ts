import { CenterDetails } from "./center-details";
import { NewVehicle } from "./new-vehicle";
import { UsedVehicle } from "./used-vehicle";
import { VinClaim } from "./vin-claim";

export class TaskDetails {

    public centerDetails : CenterDetails;
	public taskId : string;
	public creationDateTime : string;
	public taskStatus : string;
	public statusDateTime : string;
	public vin : string;
	public modelYear : number;
	public modelNumberAndDesc : string;
	public newVehicle : NewVehicle[]; 
	public usedVehicle : UsedVehicle[];
	public totalClaimAmount : string; // number
	public comment : string;
	public reviewComment : string;
	public agreed : boolean; //to be discussed
    public vinClaims : VinClaim[];
}
