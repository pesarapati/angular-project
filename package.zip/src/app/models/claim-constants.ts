
export const DefectDetailsHeaders = [
    { field: 'defectCode', header: 'Defect Code' },
    { field: 'defectDesc', header: 'Defect Description' },
    { field: 'saleStartDate', header: 'Stop Sale Start Date' },
    { field: 'availableDate', header: 'Remedy Avl Date' },
    { field: 'repairDate', header: 'Claim Repair Date ' },
    { field: 'eligibilityStartDate', header: 'Claim Eligibility Start Date' },
    { field: 'claimStartDate', header: 'Actual Claim Start Date' },
    { field: 'claimEndDate', header: 'Claim End Date' },
];


export const VinClaimHeaders = [
    { field: 'claimAmount', header: 'Claim Amount(USD)' },
    { field: 'claimNumber', header: 'Claim Number' },
    { field: 'claimPeriod', header: 'Claim-Period(s)' },
    { field: 'detailsEdited', header: 'Details Edited' },
    { field: '', header: 'Action' },
];

export const TaskHeaders = [
    { field: 'taskId', header: 'Task ID' },
    { field: 'vin', header: 'VIN' },
    { field: 'milleage', header: 'Mileage' },
    { field: 'createdBy', header: 'Created By' },
    { field: 'status', header: 'Status' },
    { field: 'statusDate', header: 'Status Date ' },
    { field: 'reimAmount', header: 'Reimbursement Amount' },
    { field: 'claimEndDate', header: 'Claim End Date' },
    { field: '', header: 'Action' }
  ];



  export const InternalTaskHeaders = [
    { field: 'taskId', header: 'Task ID' },
    { field: 'agCodeDesc', header: 'AG Code' },
    { field: 'createdBy', header: 'created By' },
    { field: 'vin', header: 'VIN' },
    { field: 'status', header: 'Status[For Dealer]' },
    { field: 'subStatus', header: 'Sub-Status' },
    { field: 'subStatusDate', header: 'Sub Status Date' },
    { field: 'manualDate', header: 'Date entered in Manual Workflow' },
    { field: 'ownedBy', header: 'Owned By' },
    { field: '', header: 'Actions' }
  ];
