import { DefectDetails } from "./defect-details";

export class NewVehicle {

    public inventoryEntryDate : string; 
	public inventoryExitDate : string;
	public wholesaleInvoicePrice : string;
	public defectDetails : DefectDetails[];
	public eligibilityPeriod : String[];
	public noOfDays : string;
	public noOfMonths : string;
    public claimAmount : string;
    

   
}
