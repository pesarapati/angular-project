import { Component, OnInit } from '@angular/core';
import { ClaimService } from '../../claim.service';
import { Router, NavigationExtras } from '@angular/router';
import { DealerInfo } from '../../models/dealer-info';
import { CenterDetails } from '../../models/center-details';

@Component({
  selector: 'app-dealer-create-task',
  templateUrl: './dealer-create-task.component.html',
  styleUrls: ['./dealer-create-task.component.css']
})
export class DealerCreateTaskComponent implements OnInit {

  dealerInput :DealerInfo;
  centerDetails :  CenterDetails;

  constructor(private claimService:ClaimService,private _rotuer:Router) { }

  ngOnInit() {
    this.dealerInput = new DealerInfo(null,null);
    this.centerDetails = JSON.parse(atob(localStorage.getItem('centerDetails')));
  }

  submitDealerForm(){
       this.claimService.submitDealerDeatils(this.dealerInput).subscribe(
         (data)=>{
         console.log('dealer-taskdetails-response : ',data);
         localStorage.setItem('dealer-taskdetails-response', btoa(JSON.stringify(data))); // Store in localstore
         this._rotuer.navigate(['d-task-details']);
       },(error)=>{
         console.log(error);
       });
  }


  get data(){
    return JSON.stringify(this.dealerInput);
  } 


}
