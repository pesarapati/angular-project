import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { ClaimService } from '../../claim.service';
import { TaskDetails } from '../../models/task-details';
import { DealerInfo } from '../../models/dealer-info';
import { CenterDetails } from '../../models/center-details';
import { Message } from 'primeng/components/common/message';
import { VinClaimHeaders, DefectDetailsHeaders } from '../../models/claim-constants';


@Component({
  selector: 'app-dealer-task-details',
  templateUrl: './dealer-task-details.component.html',
  styleUrls: ['./dealer-task-details.component.css']
})
export class DealerTaskDetailsComponent implements OnInit {

  centerDetails: CenterDetails;
  taskDetails: TaskDetails;
  defectDetailsHeaders: any[];
  vinClaimHeaders: any[];
  showComments: boolean = false;
  hide : boolean = true;

  commentsList : any[] =  [ { val: 'First comment been added by the dealer'  },  { val: 'second comment been added by the dealer ' },  { val: 'second comment been added by the dealer ' } ];


  constructor(private route: ActivatedRoute, private location: Location, private claimService: ClaimService) {
    
  }

  ngOnInit() {

    this.defectDetailsHeaders = DefectDetailsHeaders;
    this.vinClaimHeaders = VinClaimHeaders;

    if (localStorage.length > 0) {
      this.centerDetails = JSON.parse(atob(localStorage.getItem('centerDetails')));
      this.taskDetails = JSON.parse(atob(localStorage.getItem('dealer-taskdetails-response')));
      console.log('taskdeatils from localStorage : ', JSON.stringify(this.taskDetails));
    }
  }
  


  showCommentsDialog() {
      this.showComments = true;
  }

  goback(): void {
    this.location.back();
  }

  get data() {
    return JSON.stringify(this.taskDetails);
  }

}
