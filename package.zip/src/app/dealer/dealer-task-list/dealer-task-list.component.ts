import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { ClaimService } from '../../claim.service';
import { TaskInfo } from '../../models/task-info';
import { CenterDetails } from '../../models/center-details';
import { TaskHeaders } from '../../models/claim-constants';

@Component({
  selector: 'app-dealer-task-list',
  templateUrl: './dealer-task-list.component.html',
  styleUrls: ['./dealer-task-list.component.css']
})
export class DealerTaskListComponent implements OnInit {

  constructor(private router: Router,
    private claimService: ClaimService) {
  }
  vinFilterValue: string = "";
  taskHeaders: any[];
  taskList: TaskInfo[];
  centerDetails: CenterDetails;


  ngOnInit() {
    this.getDealerTasks();
    this.taskHeaders = TaskHeaders;
    this.centerDetails = JSON.parse(atob(localStorage.getItem('centerDetails')));
  }

  getDealerTasks(): void {
    this.claimService.getDealerTasks().subscribe(
      data => {
        this.taskList = data;
        console.log('getDealerTasks Response ', JSON.stringify(data));
      }, err => {
        console.log('Error while fetching the dealer tasks data');
      }
    );
  }

  viewSelectedDealerTask(taskInfo: TaskInfo) {
    console.log('viewSelectedDealerTask TaskInfo : ', JSON.stringify(taskInfo));
    this.claimService.viewDealerTask(taskInfo.taskId).subscribe(
      data => {
        console.log('getViewTaskDetails response : ', JSON.stringify(data));
        localStorage.setItem('dealer-taskdetails-response', btoa(JSON.stringify(data))); // Store in localstore
        this.router.navigate(['d-task-details']);
      }, err => {
        console.log('Error while fetching getViewTaskDetails()');
      }
    );
  }

  get data() {
    return JSON.stringify(this.taskList);
  }



  vinKeyUp(event) {
    this.vinFilterValue = event.target.value;
  }


}
