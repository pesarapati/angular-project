import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealerTaskStarterComponent } from './dealer-task-starter.component';

describe('DealerTaskStarterComponent', () => {
  let component: DealerTaskStarterComponent;
  let fixture: ComponentFixture<DealerTaskStarterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealerTaskStarterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealerTaskStarterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
