import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { ClaimService } from '../../claim.service';
import { CenterDetails } from '../../models/center-details';

@Component({
  selector: 'app-dealer-task-starter',
  templateUrl: './dealer-task-starter.component.html',
  styleUrls: ['./dealer-task-starter.component.css']
})
export class DealerTaskStarterComponent implements OnInit {

  constructor(private router: Router,  private route: ActivatedRoute,
         private claimService : ClaimService) { }

  centerDetails :  CenterDetails;
    
  ngOnInit() {
    //this.getLoginUserType();

    this.router.navigate(['d-task-list']);
  }

  getLoginUserType():void{
    this.claimService.getCenterDetails().subscribe(
      data =>{
        this.centerDetails = data;
        console.log('centerDetails response : '+JSON.stringify(this.centerDetails));
        if(this.centerDetails.dealer == false){
          localStorage.setItem('centerDetails', btoa(JSON.stringify(this.centerDetails))); // Store in localstore
          this.router.navigate(['d-task-list']);
          console.log('centerDetails are not null ! Hence User is Dealer');
        }else{
          this.router.navigate(['i-task-list']);
          console.log('centerDetails are not ! Hence User is Internal');
        }
      },err =>{
        console.log('Error while fetching the getCenterDetails() data');
      }
    );
  }

}
